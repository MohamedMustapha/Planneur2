This is a commercial Mobiscroll package, licensed to Mohamed Mustapha <dev@steamfundation.com> with license key 9341a545-d8b9-47ca-9322-f0604ba96f36.

In case of perpetual licenses please refer to the EULA licensing terms (present in the license folder) or https://mobiscroll.com/EULA for more info.

In case of SaaS licenses please refer to the license agreement you agreed to.