import { MbscDropdown } from './dropdown';
import { MbscInput } from './input';
import { MbscTextarea } from './textarea';
import * as i0 from "@angular/core";
import * as i1 from "../../core/components/input/input";
import * as i2 from "./dropdown";
import * as i3 from "./input";
import * as i4 from "./textarea";
import * as i5 from "../shared/structural-directives.module";
import * as i6 from "@angular/forms";
import * as i7 from "./icon.module";
export { MbscDropdown, MbscInput, MbscTextarea };
export * from '../../core/components/input/input.types.public';
export declare class MbscInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MbscInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MbscInputModule, [typeof i1.InputBase, typeof i2.MbscDropdown, typeof i3.MbscInput, typeof i4.MbscTextarea], [typeof i5.MbscStructuralDirectivesModule, typeof i6.FormsModule, typeof i7.MbscIconModule], [typeof i2.MbscDropdown, typeof i3.MbscInput, typeof i4.MbscTextarea]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MbscInputModule>;
}
