import { MbscPopup } from './popup';
import { MbscPrompt } from './prompt';
import { MbscSnackbar } from './snackbar';
import * as i0 from "@angular/core";
import * as i1 from "./popup";
import * as i2 from "./prompt";
import * as i3 from "./snackbar";
import * as i4 from "../../core/components/popup/popup";
import * as i5 from "@angular/common";
import * as i6 from "./button.module";
import * as i7 from "./input.module";
import * as i8 from "../shared/structural-directives.module";
export { MbscPopup, MbscPrompt, MbscSnackbar };
export * from '../../core/components/popup/popup.types.public';
export declare class MbscPopupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MbscPopupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MbscPopupModule, [typeof i1.MbscPopup, typeof i2.MbscPrompt, typeof i3.MbscSnackbar, typeof i4.PopupBase], [typeof i5.CommonModule, typeof i6.MbscButtonModule, typeof i7.MbscInputModule, typeof i8.MbscStructuralDirectivesModule], [typeof i1.MbscPopup, typeof i2.MbscPrompt, typeof i3.MbscSnackbar]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MbscPopupModule>;
}
