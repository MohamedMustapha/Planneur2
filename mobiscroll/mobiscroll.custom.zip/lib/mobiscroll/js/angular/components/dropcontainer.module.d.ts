import { MbscDropcontainer } from './dropcontainer';
import * as i0 from "@angular/core";
import * as i1 from "../../core/components/dropcontainer/dropcontainer";
import * as i2 from "./dropcontainer";
import * as i3 from "../shared/structural-directives.module";
export { MbscDropcontainer };
export * from '../../core/components/dropcontainer/dropcontainer.types.public';
export declare class MbscDropcontainerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MbscDropcontainerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MbscDropcontainerModule, [typeof i1.DropcontainerBase, typeof i2.MbscDropcontainer], [typeof i3.MbscStructuralDirectivesModule], [typeof i2.MbscDropcontainer]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MbscDropcontainerModule>;
}
