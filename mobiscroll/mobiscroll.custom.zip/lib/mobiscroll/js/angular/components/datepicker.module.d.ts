import { MbscDatepicker, MbscDatepickerDirective } from './datepicker';
import * as i0 from "@angular/core";
import * as i1 from "../../core/components/datepicker/datepicker";
import * as i2 from "./datepicker";
import * as i3 from "../shared/structural-directives.module";
import * as i4 from "@angular/forms";
import * as i5 from "./calendar.module";
import * as i6 from "./datetime.module";
import * as i7 from "./icon.module";
import * as i8 from "./input.module";
import * as i9 from "../shared/picker.module";
import * as i10 from "./popup.module";
import * as i11 from "./segmented.module";
import * as i12 from "./timegrid.module";
import * as i13 from "../shared/calendar-header.module";
export { MbscDatepicker, MbscDatepickerDirective };
export * from '../../core/components/datepicker/datepicker.public';
export * from '../shared/calendar-header.module';
export * from './calendar.module';
export * from './datetime.module';
export * from './scroller.module';
export * from './timegrid.module';
export declare class MbscDatepickerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MbscDatepickerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MbscDatepickerModule, [typeof i1.DatepickerBase, typeof i2.MbscDatepicker, typeof i2.MbscDatepickerBase, typeof i2.MbscDatepickerDirective], [typeof i3.MbscStructuralDirectivesModule, typeof i4.FormsModule, typeof i5.MbscCalendarModule, typeof i6.MbscDatetimeModule, typeof i7.MbscIconModule, typeof i8.MbscInputModule, typeof i9.MbscPickerModule, typeof i10.MbscPopupModule, typeof i11.MbscSegmentedModule, typeof i12.MbscTimegridModule], [typeof i2.MbscDatepicker, typeof i2.MbscDatepickerDirective, typeof i13.MbscCalendarHeaderModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MbscDatepickerModule>;
}
