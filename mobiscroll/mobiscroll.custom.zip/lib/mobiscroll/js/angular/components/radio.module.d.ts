import { MbscRadio } from './radio';
import { MbscRadioGroup } from './radio-group';
import * as i0 from "@angular/core";
import * as i1 from "../../core/components/radio/radio";
import * as i2 from "../../core/components/radio/radio-group";
import * as i3 from "./radio";
import * as i4 from "./radio-group";
import * as i5 from "../shared/structural-directives.module";
export { MbscRadio, MbscRadioGroup };
export * from '../../core/components/radio/radio.types.public';
export declare class MbscRadioModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MbscRadioModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MbscRadioModule, [typeof i1.RadioBase, typeof i2.RadioGroupBase, typeof i3.MbscRadio, typeof i4.MbscRadioGroup], [typeof i5.MbscStructuralDirectivesModule], [typeof i3.MbscRadio, typeof i4.MbscRadioGroup]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MbscRadioModule>;
}
