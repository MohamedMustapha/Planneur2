import { MbscSegmentedGroup } from './segmented-group';
import { MbscSegmented } from './segmented-item';
import * as i0 from "@angular/core";
import * as i1 from "../../core/components/segmented/segmented-item";
import * as i2 from "../../core/components/segmented/segmented-group";
import * as i3 from "./segmented-item";
import * as i4 from "./segmented-group";
import * as i5 from "../shared/structural-directives.module";
import * as i6 from "./button.module";
export { MbscSegmented, MbscSegmentedGroup };
export * from '../../core/components/segmented/segmented.types.public';
export declare class MbscSegmentedModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MbscSegmentedModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MbscSegmentedModule, [typeof i1.SegmentedBase, typeof i2.SegmentedGroupBase, typeof i3.MbscSegmented, typeof i4.MbscSegmentedGroup], [typeof i5.MbscStructuralDirectivesModule, typeof i6.MbscButtonModule], [typeof i3.MbscSegmented, typeof i4.MbscSegmentedGroup]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MbscSegmentedModule>;
}
