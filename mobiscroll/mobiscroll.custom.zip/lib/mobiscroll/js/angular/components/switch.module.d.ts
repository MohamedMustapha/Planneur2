import { MbscSwitch } from './switch';
import * as i0 from "@angular/core";
import * as i1 from "../../core/components/switch/switch";
import * as i2 from "./switch";
import * as i3 from "../shared/structural-directives.module";
export { MbscSwitch };
export * from '../../core/components/switch/switch.types.public';
export declare class MbscSwitchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MbscSwitchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MbscSwitchModule, [typeof i1.SwitchBase, typeof i2.MbscSwitch], [typeof i3.MbscStructuralDirectivesModule], [typeof i2.MbscSwitch]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MbscSwitchModule>;
}
