import { MbscCalendar } from './calendar';
import * as i0 from "@angular/core";
import * as i1 from "../../core/components/calendar/calendar";
import * as i2 from "./calendar";
import * as i3 from "../shared/structural-directives.module";
import * as i4 from "../shared/calendar-view.module";
export { MbscCalendar };
export declare class MbscCalendarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MbscCalendarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MbscCalendarModule, [typeof i1.CalendarBase, typeof i2.MbscCalendar], [typeof i3.MbscStructuralDirectivesModule, typeof i4.MbscCalendarViewModule], [typeof i2.MbscCalendar]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MbscCalendarModule>;
}
