import * as i0 from "@angular/core";
import * as i1 from "../shared/structural-directives.module";
import * as i2 from "./button.module";
import * as i3 from "./checkbox.module";
import * as i4 from "./input.module";
import * as i5 from "./page.module";
import * as i6 from "./radio.module";
import * as i7 from "./segmented.module";
import * as i8 from "./stepper.module";
import * as i9 from "./switch.module";
import * as i10 from "./notifications";
export * from './button.module';
export * from './checkbox.module';
export * from './icon.module';
export * from './input.module';
export * from './page.module';
export * from './radio.module';
export * from './segmented.module';
export * from './stepper.module';
export * from './switch.module';
export * from './notifications';
export declare class MbscFormsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MbscFormsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MbscFormsModule, never, [typeof i1.MbscStructuralDirectivesModule, typeof i2.MbscButtonModule, typeof i3.MbscCheckboxModule, typeof i4.MbscInputModule, typeof i5.MbscPageModule, typeof i6.MbscRadioModule, typeof i7.MbscSegmentedModule, typeof i8.MbscStepperModule, typeof i9.MbscSwitchModule], [typeof i2.MbscButtonModule, typeof i3.MbscCheckboxModule, typeof i4.MbscInputModule, typeof i5.MbscPageModule, typeof i6.MbscRadioModule, typeof i7.MbscSegmentedModule, typeof i8.MbscStepperModule, typeof i9.MbscSwitchModule, typeof i10.MbscNotificationsModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MbscFormsModule>;
}
