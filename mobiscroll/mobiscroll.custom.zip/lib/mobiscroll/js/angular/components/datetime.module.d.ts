import { MbscDate, MbscDatetime, MbscTime } from './datetime';
import * as i0 from "@angular/core";
import * as i1 from "../../core/components/datetime/datetime";
import * as i2 from "./datetime";
import * as i3 from "../shared/structural-directives.module";
import * as i4 from "@angular/forms";
import * as i5 from "./scroller.module";
export { MbscDate, MbscDatetime, MbscTime };
export declare class MbscDatetimeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MbscDatetimeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MbscDatetimeModule, [typeof i1.DatetimeBase, typeof i2.MbscDate, typeof i2.MbscDateBase, typeof i2.MbscDatetime, typeof i2.MbscTime], [typeof i3.MbscStructuralDirectivesModule, typeof i4.FormsModule, typeof i5.MbscScrollerModule], [typeof i2.MbscDate, typeof i2.MbscDatetime, typeof i2.MbscTime]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MbscDatetimeModule>;
}
