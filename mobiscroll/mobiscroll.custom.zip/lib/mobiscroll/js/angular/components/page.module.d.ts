import { MbscPage } from './page';
import * as i0 from "@angular/core";
import * as i1 from "./page";
import * as i2 from "../../core/components/page/page";
import * as i3 from "../shared/structural-directives.module";
export { MbscPage };
export * from '../../core/components/page/page.types.public';
export declare class MbscPageModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MbscPageModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MbscPageModule, [typeof i1.MbscPage, typeof i2.PageBase], [typeof i3.MbscStructuralDirectivesModule], [typeof i1.MbscPage]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MbscPageModule>;
}
