import { MbscList } from './list';
import { MbscListHeader } from './list-header';
import { MbscListItem } from './list-item';
import * as i0 from "@angular/core";
import * as i1 from "../../core/components/list/list";
import * as i2 from "../../core/components/list/list-header";
import * as i3 from "../../core/components/list/list-item";
import * as i4 from "./list";
import * as i5 from "./list-header";
import * as i6 from "./list-item";
import * as i7 from "../shared/structural-directives.module";
export { MbscList, MbscListHeader, MbscListItem };
export declare class MbscListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MbscListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MbscListModule, [typeof i1.ListBase, typeof i2.ListHeaderBase, typeof i3.ListItemBase, typeof i4.MbscList, typeof i5.MbscListHeader, typeof i6.MbscListItem], [typeof i7.MbscStructuralDirectivesModule], [typeof i4.MbscList, typeof i5.MbscListHeader, typeof i6.MbscListItem]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MbscListModule>;
}
