import { MbscButton } from './button';
import * as i0 from "@angular/core";
import * as i1 from "../../core/components/button/button";
import * as i2 from "./button";
import * as i3 from "../shared/structural-directives.module";
import * as i4 from "./icon.module";
export { MbscButton };
export * from '../../core/components/button/button.types.public';
export declare class MbscButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MbscButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MbscButtonModule, [typeof i1.ButtonBase, typeof i2.MbscButton], [typeof i3.MbscStructuralDirectivesModule, typeof i4.MbscIconModule], [typeof i2.MbscButton]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MbscButtonModule>;
}
