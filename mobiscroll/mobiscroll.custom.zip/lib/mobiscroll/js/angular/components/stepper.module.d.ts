import { MbscStepper } from './stepper';
import * as i0 from "@angular/core";
import * as i1 from "../../core/components/stepper/stepper";
import * as i2 from "./stepper";
import * as i3 from "../shared/structural-directives.module";
import * as i4 from "./button.module";
export { MbscStepper };
export * from '../../core/components/stepper/stepper.types.public';
export declare class MbscStepperModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MbscStepperModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MbscStepperModule, [typeof i1.StepperBase, typeof i2.MbscStepper], [typeof i3.MbscStructuralDirectivesModule, typeof i4.MbscButtonModule], [typeof i2.MbscStepper]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MbscStepperModule>;
}
