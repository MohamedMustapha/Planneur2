import { MbscCustomEndIcon, MbscCustomIcon, MbscCustomStartIcon, MbscIcon } from './icon';
import * as i0 from "@angular/core";
import * as i1 from "../../core/components/icon/icon";
import * as i2 from "./icon";
import * as i3 from "../shared/structural-directives.module";
export { MbscCustomEndIcon, MbscCustomIcon, MbscCustomStartIcon, MbscIcon };
export declare class MbscIconModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MbscIconModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MbscIconModule, [typeof i1.IconBase, typeof i2.MbscIcon, typeof i2.MbscCustomEndIcon, typeof i2.MbscCustomIcon, typeof i2.MbscCustomStartIcon], [typeof i3.MbscStructuralDirectivesModule], [typeof i2.MbscIcon, typeof i2.MbscCustomEndIcon, typeof i2.MbscCustomIcon, typeof i2.MbscCustomStartIcon]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MbscIconModule>;
}
