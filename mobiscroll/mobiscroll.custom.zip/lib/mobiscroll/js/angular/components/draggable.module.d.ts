import { DraggableDirective } from './draggable';
import * as i0 from "@angular/core";
import * as i1 from "../../core/components/draggable/draggable";
import * as i2 from "./draggable";
import * as i3 from "../shared/structural-directives.module";
export { DraggableDirective };
export * from '../../core/components/draggable/draggable.types.public';
export declare class MbscDraggableModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MbscDraggableModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MbscDraggableModule, [typeof i1.DraggableBase, typeof i2.DraggableDirective], [typeof i3.MbscStructuralDirectivesModule], [typeof i2.DraggableDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MbscDraggableModule>;
}
