import { MbscSelect, MbscSelectDirective, MbscSelectOptionComponent, MbscSelectOptionDirective } from './select';
import * as i0 from "@angular/core";
import * as i1 from "../../core/components/select/select";
import * as i2 from "./select";
import * as i3 from "../shared/structural-directives.module";
import * as i4 from "@angular/forms";
import * as i5 from "./scroller.module";
import * as i6 from "./icon.module";
import * as i7 from "./input.module";
import * as i8 from "./popup.module";
export { MbscSelect, MbscSelectDirective, MbscSelectOptionDirective, MbscSelectOptionComponent };
export * from '../../core/components/popup/popup.types.public';
export * from '../../core/components/select/select.types.public';
export * from './scroller.module';
export declare class MbscSelectModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MbscSelectModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MbscSelectModule, [typeof i1.SelectBase, typeof i2.MbscSelect, typeof i2.MbscSelectBase, typeof i2.MbscSelectDirective, typeof i2.MbscSelectOptionBase, typeof i2.MbscSelectOptionDirective, typeof i2.MbscSelectOptionComponent], [typeof i3.MbscStructuralDirectivesModule, typeof i4.FormsModule, typeof i5.MbscScrollerModule, typeof i6.MbscIconModule, typeof i7.MbscInputModule, typeof i8.MbscPopupModule], [typeof i2.MbscSelect, typeof i2.MbscSelectDirective, typeof i2.MbscSelectOptionDirective, typeof i2.MbscSelectOptionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MbscSelectModule>;
}
