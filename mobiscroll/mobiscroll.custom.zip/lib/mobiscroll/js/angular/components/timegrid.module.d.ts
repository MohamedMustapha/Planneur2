import { MbscTimegrid } from './timegrid';
import * as i0 from "@angular/core";
import * as i1 from "./timegrid";
import * as i2 from "../../core/components/timegrid/timegrid";
import * as i3 from "../shared/structural-directives.module";
export { MbscTimegrid };
export declare class MbscTimegridModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MbscTimegridModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MbscTimegridModule, [typeof i1.MbscTimeBox, typeof i2.TimegridBase, typeof i1.MbscTimegrid], [typeof i3.MbscStructuralDirectivesModule], [typeof i1.MbscTimegrid]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MbscTimegridModule>;
}
