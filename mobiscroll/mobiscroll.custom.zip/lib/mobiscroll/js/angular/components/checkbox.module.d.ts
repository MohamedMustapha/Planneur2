import { MbscCheckbox } from './checkbox';
import * as i0 from "@angular/core";
import * as i1 from "../../core/components/checkbox/checkbox";
import * as i2 from "./checkbox";
import * as i3 from "../shared/structural-directives.module";
export { MbscCheckbox };
export * from '../../core/components/checkbox/checkbox.types.public';
export declare class MbscCheckboxModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MbscCheckboxModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MbscCheckboxModule, [typeof i1.CheckboxBase, typeof i2.MbscCheckbox], [typeof i3.MbscStructuralDirectivesModule], [typeof i2.MbscCheckbox]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MbscCheckboxModule>;
}
