import { MbscScroller } from './scroller';
import * as i0 from "@angular/core";
import * as i1 from "./scroller";
import * as i2 from "../shared/wheel-item";
import * as i3 from "../shared/wheel";
import * as i4 from "../../core/components/scroller/scroller";
import * as i5 from "../../core/shared/wheel/wheel";
import * as i6 from "../../core/shared/wheel/wheel-item";
import * as i7 from "../shared/structural-directives.module";
import * as i8 from "@angular/common";
import * as i9 from "./input.module";
import * as i10 from "../shared/picker.module";
import * as i11 from "../shared/scroll-view.module";
export { MbscScroller };
export declare class MbscScrollerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MbscScrollerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MbscScrollerModule, [typeof i1.MbscScroller, typeof i2.MbscWheelItem, typeof i3.MbscWheel, typeof i4.ScrollerBase, typeof i5.WheelBase, typeof i6.WheelItemBase], [typeof i7.MbscStructuralDirectivesModule, typeof i8.CommonModule, typeof i9.MbscInputModule, typeof i10.MbscPickerModule, typeof i11.MbscScrollviewBaseModule], [typeof i1.MbscScroller]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MbscScrollerModule>;
}
