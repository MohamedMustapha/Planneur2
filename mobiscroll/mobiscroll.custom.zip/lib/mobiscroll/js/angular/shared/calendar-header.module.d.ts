import * as i0 from "@angular/core";
import * as i1 from "./calendar-header";
import * as i2 from "./structural-directives.module";
import * as i3 from "../components/button.module";
import * as i4 from "../components/icon.module";
export { MbscCalendarNav, MbscCalendarNext, MbscCalendarPrev, MbscCalendarToday } from './calendar-header';
export declare class MbscCalendarHeaderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MbscCalendarHeaderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MbscCalendarHeaderModule, [typeof i1.CalendarSubscriber, typeof i1.MbscCalendarNav, typeof i1.MbscCalendarNext, typeof i1.MbscCalendarPrev, typeof i1.MbscCalendarToday], [typeof i2.MbscStructuralDirectivesModule, typeof i3.MbscButtonModule, typeof i4.MbscIconModule], [typeof i1.MbscCalendarNav, typeof i1.MbscCalendarNext, typeof i1.MbscCalendarPrev, typeof i1.MbscCalendarToday]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MbscCalendarHeaderModule>;
}
