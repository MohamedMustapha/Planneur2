import * as i0 from "@angular/core";
import * as i1 from "../../core/shared/calendar-view/calendar-day";
import * as i2 from "../../core/shared/calendar-view/calendar-label";
import * as i3 from "../../core/shared/calendar-view/calendar-view";
import * as i4 from "./calendar-day";
import * as i5 from "./calendar-label";
import * as i6 from "./calendar-view";
import * as i7 from "./calendar-weekdays";
import * as i8 from "./month-view";
import * as i9 from "./multi-year-view";
import * as i10 from "./year-view";
import * as i11 from "../../core/shared/calendar-view/month-view";
import * as i12 from "@angular/common";
import * as i13 from "../components/button.module";
import * as i14 from "./calendar-header.module";
import * as i15 from "../components/icon.module";
import * as i16 from "../components/popup.module";
import * as i17 from "./scroll-view.module";
import * as i18 from "./structural-directives.module";
/** @hidden */
export declare class MbscCalendarViewModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MbscCalendarViewModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MbscCalendarViewModule, [typeof i1.CalendarDayBase, typeof i2.CalendarLabelBase, typeof i3.CalendarViewBase, typeof i4.MbscCalendarDay, typeof i5.MbscCalendarLabel, typeof i6.MbscCalendarView, typeof i7.MbscCalendarWeekDays, typeof i8.MbscMonthView, typeof i9.MbscMultiYearView, typeof i10.MbscYearView, typeof i11.MonthViewBase], [typeof i12.CommonModule, typeof i13.MbscButtonModule, typeof i14.MbscCalendarHeaderModule, typeof i15.MbscIconModule, typeof i16.MbscPopupModule, typeof i17.MbscScrollviewBaseModule, typeof i18.MbscStructuralDirectivesModule], [typeof i6.MbscCalendarView, typeof i14.MbscCalendarHeaderModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MbscCalendarViewModule>;
}
