import * as i0 from "@angular/core";
import * as i1 from "../../core/shared/picker/picker";
import * as i2 from "./structural-directives.module";
export declare class MbscPickerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MbscPickerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MbscPickerModule, [typeof i1.PickerBase], [typeof i2.MbscStructuralDirectivesModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MbscPickerModule>;
}
