import * as i0 from "@angular/core";
import * as i1 from "./scroll-view";
import * as i2 from "../../core/shared/scroll-view/scroll-view";
import * as i3 from "./structural-directives.module";
import * as i4 from "@angular/common";
/** @hidden */
export declare class MbscScrollviewBaseModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MbscScrollviewBaseModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MbscScrollviewBaseModule, [typeof i1.MbscScrollviewBase, typeof i2.ScrollviewBase], [typeof i3.MbscStructuralDirectivesModule, typeof i4.CommonModule], [typeof i1.MbscScrollviewBase]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MbscScrollviewBaseModule>;
}
